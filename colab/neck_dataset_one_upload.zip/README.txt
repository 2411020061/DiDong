Bộ dữ liệu minh họa giãn cổ: 11 ảnh Dung và 10 ảnh Sai.
Tất cả ảnh được tạo bằng AI, KHÔNG chứa hai ảnh tham chiếu gốc của người dùng.
Dung/NghiengBen: nghiêng cổ sang hai bên.
Dung/CheoXuong: cúi chéo xuống hai bên.
Sai: các tư thế ngoài bốn hướng đúng.
Tải trực tiếp ZIP này vào ô upload của colab/train.ipynb.
Đây chỉ là dữ liệu để thử quy trình; cần ảnh thật đa dạng để đánh giá model.
