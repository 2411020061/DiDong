Dung/NghiengBen: nghiêng bên; Dung/CheoXuong: cúi chéo; hướng còn lại được lật landmark khi train. Sai: ngoài bốn hướng đúng. Thêm ảnh thật trước khi train.
